// Damian, Jakubiak, 1(zsiad), 101093

#include <iostream>
using namespace std;

int main(int argc, char **argv) {
<<<<<<< HEAD
  cout<<"I love git!"<<endl;
=======

  return 0;
}

