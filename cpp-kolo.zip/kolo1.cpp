// Imie, Nazwisko, grupa(specjalnosc), nr. indeksu

#include <iostream>
using namespace std;

int main(int argc, char **argv) {
  cout<<"I don't like git"<<endl;
  return 0;
}

